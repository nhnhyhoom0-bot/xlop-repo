#!/usr/bin/env python3
import os, sys, threading, subprocess
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Pango
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import xlop_core as core
import xlop_mods as mods

LOADER_NAMES = {"vanilla": "Vanilla", "fabric": "Fabric", "quilt": "Quilt",
                "forge": "Forge", "neoforge": "NeoForge"}

CSS = b"""
window, .root { background: #0e1016; color: #e8eaf2; }
.sidebar { background: #131620; border-right: 1px solid #1f2330; }
.logo { font-size: 22px; font-weight: 800; color: #ffffff; }
.logo-sub { font-size: 11px; color: #6c7390; }
.nav { background: transparent; border: none; border-radius: 10px; padding: 11px 14px;
       color: #9aa1bd; font-weight: 600; box-shadow: none; }
.nav:hover { background: #1b1f2c; color: #ffffff; }
.nav.active { background: #2a2f6b; color: #ffffff; }
.title { font-size: 26px; font-weight: 800; color: #ffffff; }
.sub { color: #7d85a3; }
.card { background: #171a25; border: 1px solid #222638; border-radius: 14px; padding: 16px; }
.label { color: #9aa1bd; font-size: 12px; font-weight: 700; }
entry, combobox button, spinbutton { background: #0f1219; color: #e8eaf2; border: 1px solid #2a2f45;
       border-radius: 9px; padding: 8px 10px; min-height: 22px; box-shadow: none; }
entry:focus { border-color: #6c63ff; }
button.pill { background: #222741; color: #e8eaf2; border: none; border-radius: 9px;
              padding: 9px 16px; font-weight: 700; box-shadow: none; background-image: none; }
button.pill:hover { background: #2d3358; }
button.danger { background: #3a1d28; color: #ff8aa0; }
button.danger:hover { background: #4d2433; }
button.play { background-image: linear-gradient(to right, #6c63ff, #3ea8ff); color: white;
              font-size: 19px; font-weight: 900; border: none; border-radius: 14px;
              padding: 16px 48px; box-shadow: 0 6px 22px rgba(80,110,255,0.35); }
button.play:hover { background-image: linear-gradient(to right, #7e76ff, #58b4ff); }
button.play:disabled { background-image: none; background-color: #232842; color: #6c7390; box-shadow: none; }
progressbar trough { background: #1a1e2c; border-radius: 6px; min-height: 10px; border: none; }
progressbar progress { background-image: linear-gradient(to right, #6c63ff, #3ea8ff); border-radius: 6px; min-height: 10px; border: none; }
textview, textview text { background: #0b0d13; color: #aab1cc; font-family: monospace; font-size: 11px; }
list, row { background: transparent; }
row { border-radius: 10px; padding: 4px; margin: 2px 0; }
row:selected { background: #2a2f6b; }
row:hover { background: #1b1f2c; }
.badge { background: #222741; color: #aab1cc; border-radius: 6px; padding: 2px 8px; font-size: 11px; font-weight: 700; }
.badge-ms { background: #12351f; color: #5be08a; }
.badge-ely { background: #123344; color: #5bc8e0; }
.badge-off { background: #3a3012; color: #e0c05b; }
.status { color: #9aa1bd; }
.err { color: #ff8aa0; }
scale trough { background: #1a1e2c; min-height: 6px; border-radius: 4px; }
scale highlight { background: #6c63ff; border-radius: 4px; }
scale slider { background: #ffffff; border-radius: 50%; min-width: 16px; min-height: 16px; }
"""


def ui(fn, *a):
    GLib.idle_add(lambda: (fn(*a), False)[1])


def open_uri(uri):
    """Opens a link/folder through the desktop portal (works inside Flatpak too)."""
    try:
        Gtk.show_uri_on_window(None, uri, Gdk.CURRENT_TIME)
    except Exception:
        try:
            subprocess.Popen(["xdg-open", uri])
        except Exception:
            pass


def lbl(text, cls=None, xalign=0.0, wrap=False):
    l = Gtk.Label(label=text, xalign=xalign)
    l.set_line_wrap(wrap)
    if cls:
        for c in cls.split():
            l.get_style_context().add_class(c)
    return l


def btn(text, cb, cls="pill"):
    b = Gtk.Button(label=text)
    for c in cls.split():
        b.get_style_context().add_class(c)
    b.connect("clicked", lambda *_: cb())
    return b


def card(child):
    f = Gtk.Box()
    f.get_style_context().add_class("card")
    f.pack_start(child, True, True, 0)
    return f


def head_pixbuf(path, size=64):
    """Face + hat layer of a skin, scaled up crisply."""
    try:
        pb = GdkPixbuf.Pixbuf.new_from_file(path)
        if not pb.get_has_alpha():
            pb = pb.add_alpha(False, 0, 0, 0)
        face = pb.new_subpixbuf(8, 8, 8, 8).scale_simple(size, size, GdkPixbuf.InterpType.NEAREST)
        if pb.get_width() >= 48 and pb.get_height() >= 16:
            hat = pb.new_subpixbuf(40, 8, 8, 8).scale_simple(size, size, GdkPixbuf.InterpType.NEAREST)
            hat.composite(face, 0, 0, size, size, 0, 0, 1, 1, GdkPixbuf.InterpType.NEAREST, 255)
        return face
    except Exception:
        return None


def placeholder_pixbuf(size=64):
    pb = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, True, 8, 8, 8)
    pb.fill(0x3b4166ff)
    return pb.scale_simple(size, size, GdkPixbuf.InterpType.NEAREST)


def account_pixbuf(acc, size=40):
    sk = (acc or {}).get("skin")
    if sk and os.path.exists(sk.get("file", "")):
        p = head_pixbuf(sk["file"], size)
        if p:
            return p
    return placeholder_pixbuf(size)


TYPE_LABEL = {"offline": ("OFFLINE", "badge-off"), "microsoft": ("MICROSOFT", "badge-ms"),
              "elyby": ("ELY.BY", "badge-ely")}


class Win(Gtk.Window):
    def __init__(self):
        super().__init__(title="Xlop Launcher")
        self.set_default_size(1000, 660)
        self.set_icon_name("com.xlop.Launcher" if core.IN_FLATPAK else "xlop-launcher")
        self.get_style_context().add_class("root")
        core.load_cfg()
        self.skin_server = core.SkinServer()
        self.versions = []
        self.pack_slugs = [None]
        self._lv_token = 0
        self._ms_token = 0
        self._last_key = None
        self._deb_id = None
        self.running = False
        self.manifest = None

        prov = Gtk.CssProvider()
        prov.connect("parsing-error", lambda *a: None)
        try:
            prov.load_from_data(CSS)
        except GLib.Error:
            pass
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        root = Gtk.Box()
        self.add(root)
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        side.get_style_context().add_class("sidebar")
        side.set_size_request(210, -1)
        side.set_border_width(16)
        side.pack_start(lbl("XLOP", "logo"), False, False, 0)
        side.pack_start(lbl("Minecraft Launcher", "logo-sub"), False, False, 14)
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.nav = {}
        for key, name in (("play", "▶  Play"), ("accounts", "👤  Accounts"),
                          ("mods", "🧩  Mods"), ("skins", "🎨  Skins"), ("settings", "⚙  Settings")):
            b = Gtk.Button(label=name)
            b.get_style_context().add_class("nav")
            b.get_child().set_xalign(0.0)
            b.connect("clicked", lambda _b, k=key: self.go(k))
            self.nav[key] = b
            side.pack_start(b, False, False, 0)
        side.pack_end(lbl("v" + core.APP_VER, "logo-sub"), False, False, 0)
        root.pack_start(side, False, False, 0)
        root.pack_start(self.stack, True, True, 0)

        self.stack.add_named(self.build_play(), "play")
        self.stack.add_named(self.build_accounts(), "accounts")
        self.stack.add_named(self.build_mods(), "mods")
        self.stack.add_named(self.build_skins(), "skins")
        self.stack.add_named(self.build_settings(), "settings")
        self.go("play")
        self.refresh_accounts()
        self.refresh_packs()
        self.connect("destroy", Gtk.main_quit)
        threading.Thread(target=self.load_versions, daemon=True).start()

    # ── navigation ──
    def go(self, key):
        self.stack.set_visible_child_name(key)
        for k, b in self.nav.items():
            ctx = b.get_style_context()
            (ctx.add_class if k == key else ctx.remove_class)("active")
        if key == "skins":
            self.refresh_skin_page()
        if key == "mods":
            self.refresh_mods()
            self.auto_search()

    def page(self, title, subtitle):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        box.set_border_width(28)
        box.pack_start(lbl(title, "title"), False, False, 0)
        box.pack_start(lbl(subtitle, "sub"), False, False, 0)
        return box

    # ── play ──
    def build_play(self):
        p = self.page("Play", "Pick a version and an account, then hit play.")
        row = Gtk.Box(spacing=12)
        vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        vb.pack_start(lbl("VERSION", "label"), False, False, 0)
        self.ver_combo = Gtk.ComboBoxText()
        self.ver_combo.set_size_request(240, -1)
        self.ver_combo.connect("changed", self.on_version_changed)
        vb.pack_start(self.ver_combo, False, False, 0)
        row.pack_start(vb, False, False, 0)
        lb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        lb.pack_start(lbl("MOD LOADER", "label"), False, False, 0)
        self.loader_combo = Gtk.ComboBoxText()
        for n in core.LOADERS:
            self.loader_combo.append_text(LOADER_NAMES[n])
        cur = core.cfg.get("loader", "vanilla")
        self.loader_combo.set_active(core.LOADERS.index(cur) if cur in core.LOADERS else 0)
        self.loader_combo.connect("changed", self.on_loader_changed)
        lb.pack_start(self.loader_combo, False, False, 0)
        row.pack_start(lb, False, False, 0)
        lvb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        lvb.pack_start(lbl("LOADER VERSION", "label"), False, False, 0)
        self.lver_combo = Gtk.ComboBoxText()
        self.lver_combo.set_size_request(150, -1)
        self.lver_combo.append_text("Latest")
        self.lver_combo.set_active(0)
        self.lver_combo.connect("changed", self.on_lver_changed)
        lvb.pack_start(self.lver_combo, False, False, 0)
        row.pack_start(lvb, False, False, 0)
        fb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.cb_snap = Gtk.CheckButton(label="Snapshots")
        self.cb_old = Gtk.CheckButton(label="Old beta / alpha")
        self.cb_snap.set_active(core.cfg.get("snapshots", False))
        self.cb_old.set_active(core.cfg.get("old", False))
        for c in (self.cb_snap, self.cb_old):
            c.connect("toggled", self.on_filter_toggled)
            fb.pack_start(c, False, False, 0)
        row.pack_start(fb, False, False, 8)
        p.pack_start(row, False, False, 0)
        row2 = Gtk.Box(spacing=10)
        pbx = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        pbx.pack_start(lbl("PROFILE  (imported modpacks)", "label"), False, False, 0)
        self.pack_combo = Gtk.ComboBoxText()
        self.pack_combo.set_size_request(240, -1)
        self.pack_combo.connect("changed", self.on_pack_changed)
        pbx.pack_start(self.pack_combo, False, False, 0)
        row2.pack_start(pbx, False, False, 0)
        rb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        rb.pack_end(btn("Remove profile", self.remove_pack, "pill danger"), False, False, 0)
        row2.pack_start(rb, False, False, 0)
        p.pack_start(row2, False, False, 0)

        self.chip = Gtk.Box(spacing=12)
        self.chip_img = Gtk.Image()
        self.chip_name = lbl("")
        self.chip_name.set_markup("<b>No account</b>")
        self.chip_type = lbl("", "sub")
        tb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        tb.pack_start(self.chip_name, False, False, 0)
        tb.pack_start(self.chip_type, False, False, 0)
        self.chip.pack_start(self.chip_img, False, False, 0)
        self.chip.pack_start(tb, False, False, 0)
        self.chip.pack_end(btn("Change", lambda: self.go("accounts")), False, False, 0)
        p.pack_start(card(self.chip), False, False, 0)

        self.play_btn = btn("▶   PLAY", self.on_play, "play")
        pb = Gtk.Box()
        pb.pack_start(self.play_btn, False, False, 0)
        p.pack_start(pb, False, False, 6)
        self.progress = Gtk.ProgressBar()
        p.pack_start(self.progress, False, False, 0)
        self.status = lbl("Ready.", "status")
        p.pack_start(self.status, False, False, 0)
        self.log_buf = Gtk.TextView()
        self.log_buf.set_editable(False)
        self.log_buf.set_cursor_visible(False)
        self.log_buf.set_wrap_mode(Gtk.WrapMode.CHAR)
        self.log_buf.set_border_width(8)
        sw = Gtk.ScrolledWindow()
        sw.add(self.log_buf)
        self.log_sw = sw
        p.pack_start(sw, True, True, 0)
        return p

    def load_versions(self):
        try:
            self.manifest = core.get_manifest()
            ui(self.fill_versions)
        except Exception as e:
            ui(self.set_status, "Could not load versions: %s" % e, True)

    def fill_versions(self):
        if not self.manifest:
            return
        snaps, old = self.cb_snap.get_active(), self.cb_old.get_active()
        allowed = {"release"} | ({"snapshot"} if snaps else set()) | ({"old_beta", "old_alpha"} if old else set())
        self.versions = [v["id"] for v in self.manifest["versions"] if v["type"] in allowed]
        self.ver_combo.handler_block_by_func(self.on_version_changed)
        self.ver_combo.remove_all()
        for v in self.versions:
            self.ver_combo.append_text(v)
        want = core.cfg.get("version") or self.manifest["latest"]["release"]
        self.ver_combo.set_active(self.versions.index(want) if want in self.versions else 0)
        self.ver_combo.handler_unblock_by_func(self.on_version_changed)
        self.apply_pack()

    def on_filter_toggled(self, *_):
        core.cfg["snapshots"] = self.cb_snap.get_active()
        core.cfg["old"] = self.cb_old.get_active()
        core.save_cfg()
        self.fill_versions()

    def on_version_changed(self, *_):
        v = self.ver_combo.get_active_text()
        if v and not self.cur_pack():
            core.cfg["version"] = v
            core.save_cfg()
            self.refresh_loader_versions()

    def cur_loader(self):
        i = self.loader_combo.get_active()
        return core.LOADERS[i] if i >= 0 else "vanilla"

    def on_loader_changed(self, *_):
        if self.cur_pack():
            return
        core.cfg["loader"] = self.cur_loader()
        core.save_cfg()
        self.refresh_loader_versions()

    # loader version picker
    def cur_pack(self):
        pc = getattr(self, "pack_combo", None)
        i = pc.get_active() if pc else -1
        return self.pack_slugs[i] if 0 <= i < len(self.pack_slugs) else None

    def cur_lver(self):
        pk = core.cfg.get("packs", {}).get(self.cur_pack() or "")
        if pk:
            return pk.get("ver")
        i = self.lver_combo.get_active()
        return self.lver_combo.get_active_text() if i > 0 else None

    def refresh_loader_versions(self):
        loader, mc = self.cur_loader(), self.ver_combo.get_active_text()
        self._lv_token += 1
        tok = self._lv_token
        self.lver_combo.handler_block_by_func(self.on_lver_changed)
        self.lver_combo.remove_all()
        self.lver_combo.append_text("Latest")
        self.lver_combo.set_active(0)
        self.lver_combo.handler_unblock_by_func(self.on_lver_changed)
        self.lver_combo.set_sensitive(loader != "vanilla" and not self.cur_pack())
        if loader == "vanilla" or not mc:
            return

        def work():
            try:
                vs = core.list_loader_versions(loader, mc)
            except Exception:
                vs = []
            ui(self.fill_lvers, tok, loader, mc, vs)
        threading.Thread(target=work, daemon=True).start()

    def fill_lvers(self, tok, loader, mc, vs):
        if tok != self._lv_token:
            return
        self.lver_combo.handler_block_by_func(self.on_lver_changed)
        for v in vs[:80]:
            self.lver_combo.append_text(v)
        saved = core.cfg.get("lv", {}).get("%s:%s" % (loader, mc))
        self.lver_combo.set_active(vs.index(saved) + 1 if saved in vs[:80] else 0)
        self.lver_combo.handler_unblock_by_func(self.on_lver_changed)

    def on_lver_changed(self, *_):
        loader, mc = self.cur_loader(), self.ver_combo.get_active_text()
        if self.cur_pack() or loader == "vanilla" or not mc:
            return
        lv = core.cfg.setdefault("lv", {})
        key = "%s:%s" % (loader, mc)
        i = self.lver_combo.get_active()
        if i > 0:
            lv[key] = self.lver_combo.get_active_text()
        else:
            lv.pop(key, None)
        core.save_cfg()

    # profiles (imported modpacks)
    def refresh_packs(self, select=None):
        self.pack_combo.handler_block_by_func(self.on_pack_changed)
        self.pack_combo.remove_all()
        self.pack_combo.append_text("Default")
        self.pack_slugs = [None]
        for slug, pk in core.cfg.get("packs", {}).items():
            self.pack_combo.append_text(pk["name"])
            self.pack_slugs.append(slug)
        self.pack_combo.set_active(self.pack_slugs.index(select) if select in self.pack_slugs else 0)
        self.pack_combo.handler_unblock_by_func(self.on_pack_changed)
        self.apply_pack()

    def set_combo_text(self, combo, text):
        for i, r in enumerate(combo.get_model()):
            if r[0] == text:
                combo.set_active(i)
                return
        combo.append_text(text)
        combo.set_active(len(combo.get_model()) - 1)

    def apply_pack(self):
        slug = self.cur_pack()
        pk = core.cfg.get("packs", {}).get(slug or "")
        for w in (self.ver_combo, self.loader_combo):
            w.set_sensitive(pk is None)
        if pk:
            self.ver_combo.handler_block_by_func(self.on_version_changed)
            self.loader_combo.handler_block_by_func(self.on_loader_changed)
            self.set_combo_text(self.ver_combo, pk["mc"])
            self.loader_combo.set_active(core.LOADERS.index(pk["loader"]))
            self.ver_combo.handler_unblock_by_func(self.on_version_changed)
            self.loader_combo.handler_unblock_by_func(self.on_loader_changed)
            self.lver_combo.handler_block_by_func(self.on_lver_changed)
            self.lver_combo.remove_all()
            self.lver_combo.append_text(pk.get("ver") or "Latest")
            self.lver_combo.set_active(0)
            self.lver_combo.handler_unblock_by_func(self.on_lver_changed)
            self.lver_combo.set_sensitive(False)
        else:
            if self.ver_combo.get_active_text() and core.cfg.get("loader") in core.LOADERS:
                self.loader_combo.handler_block_by_func(self.on_loader_changed)
                self.loader_combo.set_active(core.LOADERS.index(core.cfg["loader"]))
                self.loader_combo.handler_unblock_by_func(self.on_loader_changed)
            if self.ver_combo.get_active_text():
                self.refresh_loader_versions()

    def on_pack_changed(self, *_):
        self.apply_pack()

    def remove_pack(self):
        slug = self.cur_pack()
        if slug:
            core.cfg.get("packs", {}).pop(slug, None)
            core.save_cfg()
            self.refresh_packs()
            self.set_status("Profile removed from the list (its files were kept).")

    def set_status(self, text, err=False):
        self.status.set_text(text)
        ctx = self.status.get_style_context()
        (ctx.add_class if err else ctx.remove_class)("err")

    def append_log(self, line):
        b = self.log_buf.get_buffer()
        b.insert(b.get_end_iter(), line + "\n")
        if b.get_line_count() > 4000:
            b.delete(b.get_start_iter(), b.get_iter_at_line(1500))
        adj = self.log_sw.get_vadjustment()
        adj.set_value(adj.get_upper())

    def on_play(self):
        acc = core.current_account()
        vid = self.ver_combo.get_active_text()
        loader = self.cur_loader()
        if not acc:
            self.go("accounts")
            return self.set_status("Add or select an account first.", True)
        if not vid:
            return self.set_status("Pick a version first.", True)
        if self.running:
            return
        self.running = True
        self.play_btn.set_sensitive(False)
        self.set_status("Starting…")
        self.progress.set_fraction(0)

        def work():
            try:
                code = core.prepare_and_launch(
                    vid, acc, self.skin_server,
                    lambda t: ui(self.set_status, t),
                    lambda f: ui(self.progress.set_fraction, min(f, 1.0)),
                    lambda l: ui(self.append_log, l),
                    loader, self.cur_lver(), self.cur_pack())
                ui(self.set_status, "Game closed (exit code %s)." % code, code not in (0, None))
            except Exception as e:
                ui(self.set_status, "Error: %s" % e, True)
                ui(self.append_log, "[xlop] ERROR: %s" % e)
            finally:
                self.running = False
                ui(self.play_btn.set_sensitive, True)
        threading.Thread(target=work, daemon=True).start()

    # ── accounts ──
    def build_accounts(self):
        p = self.page("Accounts", "Offline, Microsoft (original) and Ely.by accounts.")
        self.acc_list = Gtk.ListBox()
        self.acc_list.connect("row-selected", self.on_acc_selected)
        sw = Gtk.ScrolledWindow()
        sw.add(self.acc_list)
        c = card(sw)
        p.pack_start(c, True, True, 0)
        bar = Gtk.Box(spacing=8)
        bar.pack_start(btn("＋ Offline", self.add_offline), False, False, 0)
        bar.pack_start(btn("＋ Microsoft", self.add_microsoft), False, False, 0)
        bar.pack_start(btn("＋ Ely.by", self.add_ely), False, False, 0)
        bar.pack_end(btn("Remove", self.remove_account, "pill danger"), False, False, 0)
        p.pack_start(bar, False, False, 0)
        return p

    def refresh_accounts(self):
        self._building = True
        for ch in self.acc_list.get_children():
            self.acc_list.remove(ch)
        for acc in core.cfg["accounts"]:
            row = Gtk.ListBoxRow()
            h = Gtk.Box(spacing=12)
            h.set_border_width(6)
            h.pack_start(Gtk.Image.new_from_pixbuf(account_pixbuf(acc, 40)), False, False, 0)
            h.pack_start(lbl(acc["name"], "title" if False else None), False, False, 0)
            text, cls = TYPE_LABEL[acc["type"]]
            b = lbl(text, "badge " + cls)
            h.pack_end(b, False, False, 0)
            row.add(h)
            self.acc_list.add(row)
        self.acc_list.show_all()
        i = core.cfg.get("selected", -1)
        if 0 <= i < len(core.cfg["accounts"]):
            self.acc_list.select_row(self.acc_list.get_row_at_index(i))
        self._building = False
        self.update_chip()

    def on_acc_selected(self, _lb, row):
        if getattr(self, "_building", False) or row is None:
            return
        core.cfg["selected"] = row.get_index()
        core.save_cfg()
        self.update_chip()

    def update_chip(self):
        acc = core.current_account()
        if acc:
            self.chip_img.set_from_pixbuf(account_pixbuf(acc, 48))
            self.chip_name.set_markup("<b>%s</b>" % GLib.markup_escape_text(acc["name"]))
            self.chip_type.set_text(TYPE_LABEL[acc["type"]][0].title())
        else:
            self.chip_img.set_from_pixbuf(placeholder_pixbuf(48))
            self.chip_name.set_markup("<b>No account</b>")
            self.chip_type.set_text("Add one in Accounts")

    def add_account(self, acc):
        core.cfg["accounts"] = [a for a in core.cfg["accounts"]
                                if not (a["type"] == acc["type"] and a["name"] == acc["name"])]
        core.cfg["accounts"].append(acc)
        core.cfg["selected"] = len(core.cfg["accounts"]) - 1
        core.save_cfg()
        self.refresh_accounts()

    def remove_account(self):
        i = core.cfg.get("selected", -1)
        if 0 <= i < len(core.cfg["accounts"]):
            del core.cfg["accounts"][i]
            core.cfg["selected"] = min(i, len(core.cfg["accounts"]) - 1)
            core.save_cfg()
            self.refresh_accounts()

    def dialog(self, title, fields, ok="Add"):
        d = Gtk.Dialog(title=title, transient_for=self, modal=True)
        d.add_button("Cancel", Gtk.ResponseType.CANCEL)
        d.add_button(ok, Gtk.ResponseType.OK)
        box = d.get_content_area()
        box.set_border_width(18)
        box.set_spacing(8)
        ents = []
        for text, secret in fields:
            box.pack_start(lbl(text, "label"), False, False, 0)
            e = Gtk.Entry()
            e.set_visibility(not secret)
            e.set_activates_default(True)
            e.set_size_request(320, -1)
            box.pack_start(e, False, False, 0)
            ents.append(e)
        d.set_default_response(Gtk.ResponseType.OK)
        d.show_all()
        r = d.run()
        vals = [e.get_text() for e in ents]
        d.destroy()
        return vals if r == Gtk.ResponseType.OK else None

    def error(self, msg):
        m = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.ERROR,
                              buttons=Gtk.ButtonsType.OK, text=str(msg))
        m.run()
        m.destroy()

    def add_offline(self):
        v = self.dialog("Offline account", [("Player name", False)])
        if v:
            try:
                self.add_account(core.new_offline(v[0]))
            except ValueError as e:
                self.error(e)

    def add_ely(self):
        v = self.dialog("Ely.by account", [("Username or email", False),
                                           ("Password  (with 2FA:  password:123456)", True)], "Login")
        if not v:
            return
        self.set_status("Logging in to Ely.by…")

        def work():
            try:
                acc = core.ely_login(v[0], v[1])
                ui(self.add_account, acc)
                ui(self.set_status, "Ely.by account added.")
            except Exception as e:
                ui(self.error, e)
        threading.Thread(target=work, daemon=True).start()

    def add_microsoft(self):
        cid = core.cfg.get("ms_client_id") or core.LEGACY_MS_CLIENT
        d = Gtk.Dialog(title="Microsoft login", transient_for=self, modal=True)
        d.add_button("Cancel", Gtk.ResponseType.CANCEL)
        box = d.get_content_area()
        box.set_border_width(20)
        box.set_spacing(10)
        info = lbl("Contacting Microsoft…", None, wrap=True)
        code = Gtk.Label()
        code.set_selectable(True)
        box.pack_start(info, False, False, 0)
        box.pack_start(code, False, False, 6)
        d.show_all()
        cancelled = [False]

        def work():
            try:
                dc = core.ms_start(cid)
                url = dc.get("verification_uri") or dc.get("verification_url")
                ui(info.set_text, "Open  %s  and enter this code:" % url)
                ui(code.set_markup, "<span size='xx-large' weight='heavy'>%s</span>" % dc["user_code"])
                try:
                    ui(open_uri, url)
                except Exception:
                    pass
                acc = core.ms_poll(cid, dc, lambda: cancelled[0])
                ui(self.add_account, acc)
                ui(d.destroy)
            except Exception as e:
                if not cancelled[0]:
                    ui(d.destroy)
                    ui(self.error, e)
        threading.Thread(target=work, daemon=True).start()
        d.run()
        cancelled[0] = True
        try:
            d.destroy()
        except Exception:
            pass

    # ── mods / resource packs / shaders ──
    KINDS = ["mod", "resourcepack", "shader"]
    KIND_NAME = {"mod": "Mods", "resourcepack": "Resource packs", "shader": "Shaders"}

    def target(self):
        return self.ver_combo.get_active_text(), self.cur_loader()

    def cur_kind(self):
        i = self.mod_kind.get_active()
        return self.KINDS[i] if i >= 0 else "mod"

    def build_mods(self):
        p = self.page("Mods", "Mods, resource packs and shaders from Modrinth and CurseForge.")
        top = Gtk.Box()
        self.mods_target = lbl("", "label")
        top.pack_start(self.mods_target, False, False, 0)
        top.pack_end(btn("Import modpack (.mrpack)…", self.import_pack), False, False, 0)
        p.pack_start(top, False, False, 0)
        sr = Gtk.Box(spacing=8)
        self.mod_kind = Gtk.ComboBoxText()
        for k in self.KINDS:
            self.mod_kind.append_text(self.KIND_NAME[k])
        self.mod_kind.set_active(0)
        self.mod_kind.connect("changed", lambda *_: self.on_kind_changed())
        self.mod_q = Gtk.Entry()
        self.mod_q.set_placeholder_text("Filter by name…")
        self.mod_q.connect("activate", lambda *_: self.mod_search())
        self.mod_q.connect("changed", lambda *_: self.debounce_search())
        self.mod_src = Gtk.ComboBoxText()
        self.mod_src.append_text("Modrinth")
        self.mod_src.append_text("CurseForge")
        self.mod_src.set_active(0)
        self.mod_src.connect("changed", lambda *_: self.mod_search())
        sr.pack_start(self.mod_kind, False, False, 0)
        sr.pack_start(self.mod_q, True, True, 0)
        sr.pack_start(self.mod_src, False, False, 0)
        sr.pack_start(btn("Search", self.mod_search), False, False, 0)
        p.pack_start(sr, False, False, 0)
        cols = Gtk.Box(spacing=14)
        cols.set_homogeneous(True)
        self.mod_results = Gtk.ListBox()
        self.mod_results.set_selection_mode(Gtk.SelectionMode.NONE)
        self.mod_installed = Gtk.ListBox()
        self.mod_installed.set_selection_mode(Gtk.SelectionMode.NONE)
        for lst, title, extra in ((self.mod_results, "RESULTS", None),
                                  (self.mod_installed, "INSTALLED", btn("Open folder", self.open_mods_dir))):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            head = Gtk.Box()
            head.pack_start(lbl(title, "label"), False, False, 0)
            if extra:
                head.pack_end(extra, False, False, 0)
            box.pack_start(head, False, False, 0)
            sw = Gtk.ScrolledWindow()
            sw.set_min_content_height(220)
            sw.add(lst)
            box.pack_start(sw, True, True, 0)
            cols.pack_start(card(box), True, True, 0)
        p.pack_start(cols, True, True, 0)
        self.mod_status = lbl("", "status", wrap=True)
        p.pack_start(self.mod_status, False, False, 0)
        return p

    def on_kind_changed(self):
        for ch in self.mod_results.get_children():
            self.mod_results.remove(ch)
        self.mod_msg("")
        self.refresh_mods()
        self.mod_search()

    def debounce_search(self):
        if self._deb_id:
            GLib.source_remove(self._deb_id)
        self._deb_id = GLib.timeout_add(500, self._deb_fire)

    def _deb_fire(self):
        self._deb_id = None
        self.mod_search()
        return False

    def search_key(self):
        mc, loader = self.target()
        return (mc, loader, self.cur_kind(), self.mod_src.get_active_text(), self.cur_pack())

    def auto_search(self):
        """Show the most popular items as soon as the page opens (or the target changed)."""
        if self.search_key() != self._last_key:
            self.mod_search()

    def mod_msg(self, text, err=False):
        self.mod_status.set_text(text)
        ctx = self.mod_status.get_style_context()
        (ctx.add_class if err else ctx.remove_class)("err")

    def mods_dir(self):
        mc, loader = self.target()
        return os.path.join(core.instance_dir(mc, loader, self.cur_pack()), mods.KIND_DIR[self.cur_kind()])

    def need_loader(self):
        """Mods need a loader; resource packs and shaders work with any setup."""
        mc, loader = self.target()
        if not mc:
            self.mod_msg("Versions are still loading…", True)
            return True
        if self.cur_kind() == "mod" and loader == "vanilla":
            self.mod_msg("Pick a mod loader (Fabric, Forge…) on the Play page first.", True)
            return True
        return False

    def open_mods_dir(self):
        if self.need_loader():
            return
        os.makedirs(self.mods_dir(), exist_ok=True)
        self.open_path(self.mods_dir())

    def refresh_mods(self):
        mc, loader = self.target()
        kind = self.cur_kind()
        if not mc:
            self.mods_target.set_text("")
        elif kind == "mod" and loader == "vanilla":
            self.mods_target.set_text("NO MOD LOADER SELECTED — choose Fabric, Quilt, Forge or NeoForge on the Play page")
        else:
            self.mods_target.set_text("FOR:  %s  •  Minecraft %s%s" % (
                LOADER_NAMES[loader], mc,
                "  •  profile: " + core.cfg["packs"][self.cur_pack()]["name"] if self.cur_pack() else ""))
        for ch in self.mod_installed.get_children():
            self.mod_installed.remove(ch)
        if mc and not (kind == "mod" and loader == "vanilla"):
            for f in mods.installed(self.mods_dir(), kind):
                row = Gtk.ListBoxRow()
                h = Gtk.Box(spacing=8)
                h.set_border_width(4)
                l = lbl(f)
                l.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
                l.set_hexpand(True)
                h.pack_start(l, True, True, 0)
                h.pack_end(btn("✕", lambda f=f: self.remove_mod(f), "pill danger"), False, False, 0)
                row.add(h)
                self.mod_installed.add(row)
        self.mod_installed.show_all()

    def remove_mod(self, f):
        mods.remove(self.mods_dir(), f)
        self.refresh_mods()

    def mod_search(self):
        if self.need_loader():
            for ch in self.mod_results.get_children():
                self.mod_results.remove(ch)
            return
        mc, loader = self.target()
        kind = self.cur_kind()
        src, q = self.mod_src.get_active_text(), self.mod_q.get_text().strip()
        key = core.cfg.get("cf_key", "")
        self._last_key = self.search_key()
        self._ms_token += 1
        tok = self._ms_token
        self.mod_msg("Loading %s…" % ("popular " + self.KIND_NAME[kind].lower() if not q else src))

        def work():
            try:
                res = (mods.mr_search(q, mc, loader, kind) if src == "Modrinth"
                       else mods.cf_search(q, mc, loader, key, kind))
                if tok != self._ms_token:
                    return
                ui(self.show_results, res)
                note = ""
                if kind == "shader":
                    note = "  Shaders need Iris (Fabric/Quilt) or OptiFine to work."
                ui(self.mod_msg, ("%d result(s)." % len(res) if res else "Nothing found for this version.") + note)
            except Exception as e:
                if tok == self._ms_token:
                    self._last_key = None
                    ui(self.mod_msg, str(e), True)
        threading.Thread(target=work, daemon=True).start()

    def show_results(self, res):
        for ch in self.mod_results.get_children():
            self.mod_results.remove(ch)
        for r in res:
            row = Gtk.ListBoxRow()
            h = Gtk.Box(spacing=8)
            h.set_border_width(4)
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            t = Gtk.Label(xalign=0.0)
            t.set_markup("<b>%s</b>  <span size='small' foreground='#7d85a3'>by %s • %s ↓</span>" % (
                GLib.markup_escape_text(r["title"]), GLib.markup_escape_text(r["author"]),
                "{:,}".format(r["downloads"])))
            t.set_ellipsize(Pango.EllipsizeMode.END)
            d = lbl(r["desc"].replace("\n", " "), "sub")
            d.set_ellipsize(Pango.EllipsizeMode.END)
            d.set_max_width_chars(34)
            v.pack_start(t, False, False, 0)
            v.pack_start(d, False, False, 0)
            h.pack_start(v, True, True, 0)
            h.pack_end(btn("Install", lambda r=r: self.mod_install(r)), False, False, 0)
            row.add(h)
            self.mod_results.add(row)
        self.mod_results.show_all()

    def mod_install(self, r):
        mc, loader = self.target()
        kind = self.cur_kind()
        dest, key = self.mods_dir(), core.cfg.get("cf_key", "")
        self.mod_msg("Installing %s…" % r["title"])

        def work():
            try:
                say = lambda m: ui(self.mod_msg, m)
                if r["src"] == "modrinth":
                    got = mods.mr_install(r["id"], mc, loader, dest, say, None, kind)
                else:
                    got = mods.cf_install(r["id"], mc, loader, key, dest, say, None, kind)
                ui(self.mod_msg, "Installed %d file(s)%s." % (
                    len(got), " (including required dependencies)" if len(got) > 1 else ""))
            except Exception as e:
                ui(self.mod_msg, str(e), True)
            ui(self.refresh_mods)
        threading.Thread(target=work, daemon=True).start()

    def import_pack(self):
        d = Gtk.FileChooserDialog(title="Choose a Modrinth modpack", parent=self,
                                  action=Gtk.FileChooserAction.OPEN)
        d.add_button("Cancel", Gtk.ResponseType.CANCEL)
        d.add_button("Import", Gtk.ResponseType.OK)
        f = Gtk.FileFilter()
        f.set_name("Modrinth modpack (.mrpack)")
        f.add_pattern("*.mrpack")
        d.add_filter(f)
        ok = d.run() == Gtk.ResponseType.OK
        path = d.get_filename() if ok else None
        d.destroy()
        if not path:
            return
        self.mod_msg("Importing modpack…")

        def work():
            try:
                slug = core.import_mrpack(path, lambda t: ui(self.mod_msg, t),
                                          lambda x: ui(self.progress.set_fraction, min(x, 1.0)))
                ui(self.refresh_packs, slug)
                ui(self.mod_msg, "Modpack imported. Select it under PROFILE on the Play page and press Play "
                                 "(the first launch installs the loader).")
                ui(self.refresh_mods)
            except Exception as e:
                ui(self.mod_msg, "Import failed: %s" % e, True)
        threading.Thread(target=work, daemon=True).start()

    # ── skins ──
    def build_skins(self):
        p = self.page("Skins", "Use any skin image, or copy the skin of a real player by name.")
        row = Gtk.Box(spacing=18)
        self.skin_img = Gtk.Image()
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        left.pack_start(self.skin_img, False, False, 0)
        self.skin_who = lbl("", "sub", 0.5)
        left.pack_start(self.skin_who, False, False, 0)
        row.pack_start(card(left), False, False, 0)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        right.pack_start(lbl("FROM A FILE", "label"), False, False, 0)
        right.pack_start(btn("Choose skin image (PNG 64×64)…", self.choose_skin_file), False, False, 0)
        right.pack_start(lbl("FROM A REAL PLAYER", "label"), False, False, 6)
        pr = Gtk.Box(spacing=8)
        self.premium_entry = Gtk.Entry()
        self.premium_entry.set_placeholder_text("Premium player name, e.g. Notch")
        self.premium_entry.set_hexpand(True)
        pr.pack_start(self.premium_entry, True, True, 0)
        pr.pack_start(btn("Get skin", self.get_premium_skin), False, False, 0)
        right.pack_start(pr, False, False, 0)
        right.pack_start(lbl("MODEL", "label"), False, False, 6)
        mr = Gtk.Box(spacing=14)
        self.r_classic = Gtk.RadioButton.new_with_label_from_widget(None, "Classic (Steve)")
        self.r_slim = Gtk.RadioButton.new_with_label_from_widget(self.r_classic, "Slim (Alex)")
        self.r_classic.connect("toggled", self.on_model_toggled)
        mr.pack_start(self.r_classic, False, False, 0)
        mr.pack_start(self.r_slim, False, False, 0)
        right.pack_start(mr, False, False, 0)
        right.pack_start(btn("Remove skin", self.remove_skin, "pill danger"), False, False, 8)
        self.skin_note = lbl("", "sub", wrap=True)
        right.pack_start(self.skin_note, False, False, 0)
        row.pack_start(card(right), True, True, 0)
        p.pack_start(row, False, False, 0)
        return p

    def refresh_skin_page(self):
        acc = core.current_account()
        if not acc:
            self.skin_img.set_from_pixbuf(placeholder_pixbuf(128))
            self.skin_who.set_text("No account selected")
            self.skin_note.set_text("Select an account first.")
            return
        sk = acc.get("skin")
        pb = head_pixbuf(sk["file"], 128) if sk and os.path.exists(sk.get("file", "")) else None
        self.skin_img.set_from_pixbuf(pb or placeholder_pixbuf(128))
        self.skin_who.set_text(acc["name"])
        self._building_model = True
        (self.r_slim if sk and sk.get("model") == "slim" else self.r_classic).set_active(True)
        self._building_model = False
        if acc["type"] == "offline":
            self.skin_note.set_text("The skin is applied when you launch (Minecraft 1.7+). "
                                    "Other players on a server will not see offline skins "
                                    "unless the server has a skin plugin.")
        else:
            self.skin_note.set_text("This account's skin is managed by %s. "
                                    "Select an offline account to install a custom skin."
                                    % TYPE_LABEL[acc["type"]][0].title())

    def offline_acc(self):
        acc = core.current_account()
        if not acc or acc["type"] != "offline":
            self.error("Select an offline account first (Accounts page).")
            return None
        return acc

    def choose_skin_file(self):
        acc = self.offline_acc()
        if not acc:
            return
        d = Gtk.FileChooserDialog(title="Choose a skin", parent=self, action=Gtk.FileChooserAction.OPEN)
        d.add_button("Cancel", Gtk.ResponseType.CANCEL)
        d.add_button("Open", Gtk.ResponseType.OK)
        f = Gtk.FileFilter()
        f.set_name("PNG images")
        f.add_mime_type("image/png")
        d.add_filter(f)
        if d.run() == Gtk.ResponseType.OK:
            path = d.get_filename()
            d.destroy()
            try:
                core.install_skin_file(acc, path, "slim" if self.r_slim.get_active() else "classic")
                self.refresh_skin_page()
                self.refresh_accounts()
            except Exception as e:
                self.error(e)
        else:
            d.destroy()

    def get_premium_skin(self):
        acc = self.offline_acc()
        name = self.premium_entry.get_text().strip()
        if not acc or not name:
            return
        self.skin_who.set_text("Downloading…")

        def work():
            try:
                data, model = core.fetch_premium_skin(name)
                core.install_skin_bytes(acc, data, model)
                ui(self.refresh_skin_page)
                ui(self.refresh_accounts)
            except Exception as e:
                ui(self.refresh_skin_page)
                ui(self.error, e)
        threading.Thread(target=work, daemon=True).start()

    def on_model_toggled(self, *_):
        if getattr(self, "_building_model", False):
            return
        acc = core.current_account()
        if acc and acc["type"] == "offline" and acc.get("skin"):
            acc["skin"]["model"] = "slim" if self.r_slim.get_active() else "classic"
            core.save_cfg()

    def remove_skin(self):
        acc = self.offline_acc()
        if acc and acc.pop("skin", None):
            core.save_cfg()
            self.refresh_skin_page()
            self.refresh_accounts()

    # ── settings ──
    def build_settings(self):
        p = self.page("Settings", "Memory, Java and login options.")
        g = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        g.pack_start(lbl("MEMORY (RAM)", "label"), False, False, 0)
        self.ram_lbl = lbl("", "sub")
        adj = Gtk.Adjustment(value=core.cfg.get("ram", 2048), lower=512, upper=1536 if core.is_32bit() else 16384,
                             step_increment=256, page_increment=1024)
        sc = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, adjustment=adj)
        sc.set_draw_value(False)
        sc.connect("value-changed", self.on_ram)
        g.pack_start(sc, False, False, 0)
        g.pack_start(self.ram_lbl, False, False, 0)
        self.on_ram(sc)
        g.pack_start(lbl("JAVA PATH  (empty = automatic)", "label"), False, False, 6)
        self.java_e = Gtk.Entry()
        self.java_e.set_text(core.cfg.get("java", ""))
        self.java_e.connect("changed", lambda e: self.set_cfg("java", e.get_text().strip()))
        g.pack_start(self.java_e, False, False, 0)
        g.pack_start(lbl("MICROSOFT CLIENT ID  (advanced)", "label"), False, False, 6)
        self.ms_e = Gtk.Entry()
        self.ms_e.set_text(core.cfg.get("ms_client_id", core.LEGACY_MS_CLIENT))
        self.ms_e.connect("changed", lambda e: self.set_cfg("ms_client_id",
                                                            e.get_text().strip() or core.LEGACY_MS_CLIENT))
        g.pack_start(self.ms_e, False, False, 0)
        g.pack_start(lbl("CURSEFORGE API KEY  (free at console.curseforge.com)", "label"), False, False, 6)
        self.cf_e = Gtk.Entry()
        self.cf_e.set_text(core.cfg.get("cf_key", ""))
        self.cf_e.set_visibility(False)
        self.cf_e.connect("changed", lambda e: self.set_cfg("cf_key", e.get_text().strip()))
        g.pack_start(self.cf_e, False, False, 0)
        g.pack_start(lbl("GAME FOLDER", "label"), False, False, 6)
        gr = Gtk.Box(spacing=8)
        gr.pack_start(lbl(core.GAME, "sub"), False, False, 0)
        gr.pack_end(btn("Open", lambda: self.open_path(core.GAME)), False, False, 0)
        g.pack_start(gr, False, False, 0)
        p.pack_start(card(g), False, False, 0)
        return p

    def open_path(self, path):
        os.makedirs(path, exist_ok=True)
        open_uri(GLib.filename_to_uri(path, None))

    def set_cfg(self, k, v):
        core.cfg[k] = v
        core.save_cfg()

    def on_ram(self, sc):
        v = int(sc.get_value() // 256 * 256)
        core.cfg["ram"] = v
        core.save_cfg()
        self.ram_lbl.set_text("%.1f GB" % (v / 1024))


def main():
    if core.IN_FLATPAK:
        GLib.set_prgname("com.xlop.Launcher")
    w = Win()
    w.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
