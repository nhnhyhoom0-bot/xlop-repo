"""Content search/install for Modrinth and CurseForge: mods, resource packs, shaders."""
import os, json, shutil, urllib.parse
from xlop_core import req, download

MR = "https://api.modrinth.com/v2"
CF = "https://api.curseforge.com/v1"
CF_LOADER = {"forge": 1, "fabric": 4, "quilt": 4, "neoforge": 6}   # Quilt runs Fabric mods
CF_CLASS = {"mod": 6, "resourcepack": 12, "shader": 6552}
KIND_DIR = {"mod": "mods", "resourcepack": "resourcepacks", "shader": "shaderpacks"}


def _loaders(loader):
    return ["quilt", "fabric"] if loader == "quilt" else [loader]


# ── Modrinth ──
def mr_search(q, mc, loader, kind="mod", limit=25):
    facets = [["project_type:" + kind], ["versions:" + mc]]
    if kind == "mod":
        facets.append(["categories:" + l for l in _loaders(loader)])
    url = MR + "/search?" + urllib.parse.urlencode(
        {"query": q, "facets": json.dumps(facets), "limit": limit,
         "index": "relevance" if q else "downloads"})
    c, j = req(url)
    if c != 200:
        raise RuntimeError("Modrinth error (%s)" % c)
    return [{"src": "modrinth", "id": h["project_id"], "title": h["title"], "author": h.get("author", ""),
             "desc": h.get("description", ""), "downloads": h.get("downloads", 0)} for h in j.get("hits", [])]


def mr_install(pid, mc, loader, dest, log, seen=None, kind="mod"):
    seen = set() if seen is None else seen
    if pid in seen:
        return []
    seen.add(pid)
    params = {"game_versions": json.dumps([mc])}
    if kind == "mod":
        params["loaders"] = json.dumps(_loaders(loader))
    c, vs = req("%s/project/%s/version?%s" % (MR, pid, urllib.parse.urlencode(params)))
    if c != 200 or not vs:
        raise RuntimeError("No compatible file for Minecraft %s" % mc)
    v = vs[0]
    f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
    dst = os.path.join(dest, f["filename"])
    if not os.path.exists(dst):
        download(f["url"], dst, f.get("hashes", {}).get("sha1"))
    log("Installed " + f["filename"])
    got = [f["filename"]]
    if kind == "mod":
        for d in v.get("dependencies", []):
            if d.get("dependency_type") == "required" and d.get("project_id"):
                try:
                    got += mr_install(d["project_id"], mc, loader, dest, log, seen, kind)
                except Exception as e:
                    log("Dependency skipped: %s" % e)
    return got


# ── CurseForge ──
def _cf(key):
    if not key:
        raise RuntimeError("CurseForge needs a free API key. Get one at console.curseforge.com "
                           "and paste it in Settings.")
    return {"x-api-key": key}


def cf_search(q, mc, loader, key, kind="mod", limit=25):
    h = _cf(key)
    params = {"gameId": 432, "classId": CF_CLASS[kind], "gameVersion": mc,
              "pageSize": limit, "sortField": 2, "sortOrder": "desc"}
    if kind == "mod":
        params["modLoaderType"] = CF_LOADER[loader]
    if q:
        params["searchFilter"] = q
    c, j = req(CF + "/mods/search?" + urllib.parse.urlencode(params), headers=h)
    if c in (401, 403):
        raise RuntimeError("CurseForge rejected the API key")
    if c != 200:
        raise RuntimeError("CurseForge error (%s)" % c)
    return [{"src": "curseforge", "id": m["id"], "title": m["name"],
             "author": (m.get("authors") or [{}])[0].get("name", ""), "desc": m.get("summary", ""),
             "downloads": int(m.get("downloadCount", 0))} for m in j.get("data", [])]


def cf_install(mid, mc, loader, key, dest, log, seen=None, kind="mod"):
    h = _cf(key)
    seen = set() if seen is None else seen
    if mid in seen:
        return []
    seen.add(mid)
    params = {"gameVersion": mc, "pageSize": 30}
    if kind == "mod":
        params["modLoaderType"] = CF_LOADER[loader]
    c, j = req("%s/mods/%s/files?%s" % (CF, mid, urllib.parse.urlencode(params)), headers=h)
    files = sorted(j.get("data", []) if c == 200 else [], key=lambda f: f.get("fileDate", ""), reverse=True)
    files = [f for f in files if f.get("releaseType", 1) == 1] or files
    if not files:
        raise RuntimeError("No compatible file for Minecraft %s" % mc)
    f = files[0]
    if not f.get("downloadUrl"):
        raise RuntimeError("The author of '%s' disabled downloads outside curseforge.com. "
                           "Download it from the website into the folder." % f.get("displayName", mid))
    sha = next((x["value"] for x in f.get("hashes", []) if x.get("algo") == 1), None)
    dst = os.path.join(dest, f["fileName"])
    if not os.path.exists(dst):
        download(f["downloadUrl"], dst, sha)
    log("Installed " + f["fileName"])
    got = [f["fileName"]]
    if kind == "mod":
        for d in f.get("dependencies", []):
            if d.get("relationType") == 3:            # required dependency
                try:
                    got += cf_install(d["modId"], mc, loader, key, dest, log, seen, kind)
                except Exception as e:
                    log("Dependency skipped: %s" % e)
    return got


# ── local files ──
def installed(folder, kind="mod"):
    try:
        names = os.listdir(folder)
    except FileNotFoundError:
        return []
    if kind == "mod":
        return sorted(n for n in names if n.endswith(".jar"))
    return sorted(n for n in names if n.endswith(".zip") or os.path.isdir(os.path.join(folder, n)))


def remove(folder, name):
    p = os.path.join(folder, name)
    if os.path.isdir(p):
        shutil.rmtree(p, ignore_errors=True)
    elif os.path.exists(p):
        os.remove(p)
