"""Xlop Launcher core: accounts, versions, downloads, launching, skin server."""
import os, sys, re, json, time, uuid, glob, shutil, hashlib, base64, struct, zipfile
import platform, threading, subprocess, urllib.request, urllib.parse, urllib.error
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, HTTPServer
try:                                    # Python 3.7+
    from http.server import ThreadingHTTPServer
except ImportError:                     # older Python (3.5 / 3.6)
    import socketserver

    class ThreadingHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
        daemon_threads = True

APP_NAME = "Xlop Launcher"
APP_VER = "1.2.4"
IN_FLATPAK = os.path.exists("/.flatpak-info")
if IN_FLATPAK:   # inside the sandbox ~ is not writable; XDG_DATA_HOME is ~/.var/app/<id>/data
    HOME = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "xlop")
else:
    HOME = os.path.expanduser("~/.xlop")
GAME = os.path.join(HOME, "minecraft")
CFG_PATH = os.path.join(HOME, "config.json")
SKIN_DIR = os.path.join(HOME, "skins")
UA = "XlopLauncher/" + APP_VER
LEGACY_MS_CLIENT = "00000000402b5328"
MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
RUNTIME_ALL = ("https://launchermeta.mojang.com/v1/products/java-runtime/"
               "2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json")
ELY_AUTH = "https://authserver.ely.by"
ELY_INJECTOR_API = "https://authserver.ely.by/api/authlib-injector"
INJECTOR_META = ["https://authlib-injector.yushi.moe/artifact/latest.json",
                 "https://bmclapi2.bangbang93.com/mirrors/authlib-injector/artifact/latest.json"]


# ───────────────────────── config ─────────────────────────
DEFAULT_CFG = {"accounts": [], "selected": -1, "version": "", "ram": 2048,
               "java": "", "ms_client_id": LEGACY_MS_CLIENT,
               "snapshots": False, "old": False}
cfg = dict(DEFAULT_CFG)


def load_cfg():
    os.makedirs(HOME, exist_ok=True)
    try:
        with open(CFG_PATH, encoding="utf8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    return cfg


def save_cfg():
    os.makedirs(HOME, exist_ok=True)
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf8") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CFG_PATH)


def current_account():
    i = cfg.get("selected", -1)
    return cfg["accounts"][i] if 0 <= i < len(cfg["accounts"]) else None


# ───────────────────────── http ─────────────────────────
def req(url, data=None, headers=None, method=None, form=False, timeout=30):
    """Returns (status, json). Never raises on HTTP errors."""
    h = {"User-Agent": UA, "Accept": "application/json"}
    h.update(headers or {})
    body = None
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode()
            h["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            body = json.dumps(data).encode()
            h["Content-Type"] = "application/json"
    r = urllib.request.Request(url, body, h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            raw, code = resp.read(), resp.status
    except urllib.error.HTTPError as e:
        raw, code = e.read(), e.code
    try:
        js = json.loads(raw.decode("utf8", "replace")) if raw else {}
    except Exception:
        js = {"raw": raw.decode("utf8", "replace")}
    return code, js


def jget(url):
    c, j = req(url)
    if c != 200:
        raise RuntimeError("HTTP %s for %s" % (c, url))
    return j


def fetch_bytes(url, timeout=60):
    r = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(r, timeout=timeout) as resp:
        return resp.read()


def download(url, path, sha1=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".part"
    data = fetch_bytes(url, 120)
    if sha1 and hashlib.sha1(data).hexdigest() != sha1:
        raise RuntimeError("Checksum mismatch: " + url)
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


def fetch_all(items, cb=None, workers=16):
    """items: [(url, path, sha1)]; skips files that already exist."""
    todo = [i for i in items if not (os.path.exists(i[1]) and os.path.getsize(i[1]) > 0)]
    n, done, lock = len(todo), [0], threading.Lock()

    def one(i):
        for t in range(3):
            try:
                download(*i)
                break
            except Exception:
                if t == 2:
                    raise
                time.sleep(1)
        with lock:
            done[0] += 1
            if cb:
                cb(done[0], n)
    if todo:
        with ThreadPoolExecutor(workers) as ex:
            list(ex.map(one, todo))


# ───────────────────────── accounts ─────────────────────────
def offline_uuid(name):
    b = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode()).digest())
    b[6] = (b[6] & 0x0F) | 0x30
    b[8] = (b[8] & 0x3F) | 0x80
    return b.hex()


def new_offline(name):
    name = name.strip()
    if not re.fullmatch(r"[A-Za-z0-9_]{3,16}", name):
        raise ValueError("Name must be 3-16 characters: letters, digits, underscore")
    return {"type": "offline", "name": name, "uuid": offline_uuid(name), "token": "0"}


def ely_login(user, password):
    ct = uuid.uuid4().hex
    c, r = req(ELY_AUTH + "/auth/authenticate",
               {"username": user, "password": password, "clientToken": ct, "requestUser": True})
    if c != 200:
        msg = r.get("errorMessage") or r.get("error") or "Login failed"
        if "two factor" in msg.lower():
            msg += " — enter the password like  password:123456  (password, colon, 2FA code)"
        raise RuntimeError(msg)
    p = r["selectedProfile"]
    return {"type": "elyby", "name": p["name"], "uuid": p["id"],
            "token": r["accessToken"], "client": ct}


def ely_refresh(acc):
    c, _ = req(ELY_AUTH + "/auth/validate", {"accessToken": acc["token"]})
    if c in (200, 204):
        return
    c, r = req(ELY_AUTH + "/auth/refresh", {"accessToken": acc["token"], "clientToken": acc["client"]})
    if c != 200:
        raise RuntimeError("Ely.by session expired — please add the account again")
    acc["token"] = r["accessToken"]


def _ms_endpoints(client_id):
    if client_id == LEGACY_MS_CLIENT:
        return ("https://login.live.com/oauth20_connect.srf",
                "https://login.live.com/oauth20_token.srf",
                "service::user.auth.xboxlive.com::MBI_SSL", "t=")
    base = "https://login.microsoftonline.com/consumers/oauth2/v2.0/"
    return base + "devicecode", base + "token", "XboxLive.signin offline_access", "d="


def ms_start(client_id):
    dev, _, scope, _ = _ms_endpoints(client_id)
    c, d = req(dev, {"client_id": client_id, "scope": scope, "response_type": "device_code"}, form=True)
    if c != 200:
        raise RuntimeError(d.get("error_description") or "Could not start Microsoft login")
    return d  # user_code, verification_uri, device_code, interval, expires_in


def ms_poll(client_id, d, cancelled=lambda: False):
    _, tok, _, _ = _ms_endpoints(client_id)
    end = time.time() + d.get("expires_in", 900)
    iv = d.get("interval", 5)
    while time.time() < end:
        if cancelled():
            raise RuntimeError("Cancelled")
        time.sleep(iv)
        c, t = req(tok, {"grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                         "client_id": client_id, "device_code": d["device_code"]}, form=True)
        if c == 200:
            return ms_chain(client_id, t["access_token"], t.get("refresh_token"))
        if t.get("error") in ("authorization_pending", "slow_down"):
            continue
        raise RuntimeError(t.get("error_description") or t.get("error") or "Login failed")
    raise RuntimeError("Login timed out")


def ms_chain(client_id, access, refresh):
    prefix = _ms_endpoints(client_id)[3]
    c, x = req("https://user.auth.xboxlive.com/user/authenticate",
               {"Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com",
                               "RpsTicket": prefix + access},
                "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"})
    if c != 200:
        raise RuntimeError("Xbox Live sign-in failed (%s)" % c)
    c, s = req("https://xsts.auth.xboxlive.com/xsts/authorize",
               {"Properties": {"SandboxId": "RETAIL", "UserTokens": [x["Token"]]},
                "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"})
    if c != 200:
        errs = {2148916233: "This Microsoft account has no Xbox profile. Create one at xbox.com first.",
                2148916238: "This is a child account; add it to a Microsoft Family first."}
        raise RuntimeError(errs.get(s.get("XErr"), "XSTS authorization failed (%s)" % c))
    uhs = s["DisplayClaims"]["xui"][0]["uhs"]
    c, m = req("https://api.minecraftservices.com/authentication/login_with_xbox",
               {"identityToken": "XBL3.0 x=%s;%s" % (uhs, s["Token"])})
    if c != 200:
        raise RuntimeError("Minecraft services login failed (%s)" % c)
    mc = m["access_token"]
    c, p = req("https://api.minecraftservices.com/minecraft/profile",
               headers={"Authorization": "Bearer " + mc})
    if c != 200:
        raise RuntimeError("This account does not own Minecraft: Java Edition")
    return {"type": "microsoft", "name": p["name"], "uuid": p["id"], "token": mc,
            "refresh": refresh, "exp": time.time() + m.get("expires_in", 86400) - 300}


def refresh_account(acc):
    """Make sure the account's token is valid before launching."""
    if acc["type"] == "microsoft" and time.time() > acc.get("exp", 0):
        cid = cfg.get("ms_client_id") or LEGACY_MS_CLIENT
        _, tok, scope, _ = _ms_endpoints(cid)
        c, t = req(tok, {"grant_type": "refresh_token", "client_id": cid,
                         "refresh_token": acc.get("refresh", ""), "scope": scope}, form=True)
        if c != 200:
            raise RuntimeError("Microsoft session expired — please add the account again")
        new = ms_chain(cid, t["access_token"], t.get("refresh_token", acc.get("refresh")))
        acc.update(new)
        save_cfg()
    elif acc["type"] == "elyby":
        ely_refresh(acc)
        save_cfg()


# ───────────────────────── skins ─────────────────────────
def png_size(data):
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Skin must be a PNG image")
    return struct.unpack(">II", data[16:24])


def check_skin(data):
    w, h = png_size(data)
    if (w, h) not in ((64, 64), (64, 32)):
        raise ValueError("Skin must be 64x64 (or 64x32). This image is %dx%d" % (w, h))


def install_skin_file(acc, path, model="classic"):
    with open(path, "rb") as f:
        data = f.read()
    check_skin(data)
    return install_skin_bytes(acc, data, model)


def install_skin_bytes(acc, data, model="classic"):
    check_skin(data)
    os.makedirs(SKIN_DIR, exist_ok=True)
    dst = os.path.join(SKIN_DIR, "%s_%s.png" % (acc["uuid"], hashlib.md5(data).hexdigest()[:8]))
    with open(dst, "wb") as f:
        f.write(data)
    acc["skin"] = {"file": dst, "model": model}
    save_cfg()
    return dst


def fetch_premium_skin(username):
    """Download the skin of a real Minecraft player by name. Returns (png_bytes, model)."""
    c, p = req("https://api.mojang.com/users/profiles/minecraft/" + urllib.parse.quote(username.strip()))
    if c != 200 or "id" not in p:
        raise RuntimeError("Player '%s' was not found" % username)
    c, prof = req("https://sessionserver.mojang.com/session/minecraft/profile/" + p["id"])
    if c != 200:
        raise RuntimeError("Could not read the player's profile (try again in a minute)")
    for prop in prof.get("properties", []):
        if prop["name"] == "textures":
            tex = json.loads(base64.b64decode(prop["value"]).decode("utf8"))["textures"].get("SKIN")
            if not tex:
                raise RuntimeError("This player uses a default skin")
            model = "slim" if tex.get("metadata", {}).get("model") == "slim" else "classic"
            return fetch_bytes(tex["url"]), model
    raise RuntimeError("No skin data found")


class SkinServer:
    """Tiny local Yggdrasil-style server; with authlib-injector it lets offline
    accounts show a custom skin in the game."""

    def __init__(self):
        self.state = {"uuid": "", "name": "", "png": None, "model": "classic"}
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, body=b"", ctype="application/json"):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def _json(self, obj, code=200):
                self._send(code, json.dumps(obj).encode())

            def _profile(self):
                s = outer.state
                host = "http://127.0.0.1:%d" % outer.port
                tex = {"SKIN": {"url": host + "/textures/skin.png"}}
                if s["model"] == "slim":
                    tex["SKIN"]["metadata"] = {"model": "slim"}
                val = {"timestamp": int(time.time() * 1000), "profileId": s["uuid"],
                       "profileName": s["name"], "textures": tex if s["png"] else {}}
                return {"id": s["uuid"], "name": s["name"], "properties": [
                    {"name": "textures", "value": base64.b64encode(json.dumps(val).encode()).decode()}]}

            def do_GET(self):
                path = self.path.split("?")[0]
                s = outer.state
                if path in ("", "/"):
                    return self._json({"meta": {"serverName": "Xlop Local Skins",
                                                "implementationName": "xlop-launcher",
                                                "implementationVersion": APP_VER},
                                       "skinDomains": ["127.0.0.1", "localhost"]})
                if path == "/textures/skin.png" and s["png"]:
                    return self._send(200, s["png"], "image/png")
                if path.startswith("/sessionserver/session/minecraft/profile/"):
                    return self._json(self._profile())
                if path.startswith("/sessionserver/session/minecraft/hasJoined"):
                    return self._json(self._profile())
                if path.startswith("/api/users/profiles/minecraft/"):
                    return self._json({"id": s["uuid"], "name": s["name"]})
                self._send(404, b"{}")

            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = self.rfile.read(n) if n else b""
                path = self.path.split("?")[0]
                if path == "/api/profiles/minecraft":
                    return self._json([{"id": outer.state["uuid"], "name": outer.state["name"]}])
                if path.endswith("/join"):
                    return self._send(204)
                self._send(404, b"{}")

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def set(self, acc):
        png, model = None, "classic"
        sk = acc.get("skin")
        if sk and os.path.exists(sk.get("file", "")):
            with open(sk["file"], "rb") as f:
                png = f.read()
            model = sk.get("model", "classic")
        self.state = {"uuid": acc["uuid"], "name": acc["name"], "png": png, "model": model}

    @property
    def url(self):
        return "http://127.0.0.1:%d" % self.port


# ───────────────────────── versions ─────────────────────────
def get_manifest():
    cache = os.path.join(HOME, "version_manifest.json")
    try:
        m = jget(MANIFEST_URL)
        os.makedirs(HOME, exist_ok=True)
        with open(cache, "w") as f:
            json.dump(m, f)
        return m
    except Exception:
        with open(cache) as f:
            return json.load(f)


def merge_versions(p, c):
    m = dict(p)
    for k, v in c.items():
        if k == "libraries":
            m["libraries"] = list(v) + list(p.get("libraries", []))
        elif k == "arguments":
            pa = p.get("arguments", {})
            m["arguments"] = {"game": pa.get("game", []) + v.get("game", []),
                              "jvm": pa.get("jvm", []) + v.get("jvm", [])}
        elif k != "inheritsFrom":
            m[k] = v
    m["_base"] = p.get("_base", p["id"])
    return m


def get_version_json(vid, manifest):
    p = os.path.join(GAME, "versions", vid, vid + ".json")
    if not os.path.exists(p):
        ent = next((v for v in manifest["versions"] if v["id"] == vid), None)
        if not ent:
            raise RuntimeError("Unknown version " + vid)
        download(ent["url"], p, ent.get("sha1"))
    with open(p, encoding="utf8") as f:
        j = json.load(f)
    if "inheritsFrom" in j:
        j = merge_versions(get_version_json(j["inheritsFrom"], manifest), j)
    return j


def is_32bit():
    """True for a 32-bit userland (even on a 64-bit kernel)."""
    return sys.maxsize <= 2 ** 32


def check_platform(vj):
    """Fail early with a clear message instead of crashing inside the game."""
    if is_32bit() and any(l.get("name", "").startswith("org.lwjgl:lwjgl:") for l in vj.get("libraries", [])):
        raise RuntimeError("32-bit Linux can only run Minecraft up to 1.12.2 "
                           "(newer versions need 64-bit native libraries). "
                           "Pick 1.12.2 or older, or use a 64-bit system.")


def _arch_ok(a):
    m = platform.machine().lower()
    if a == "x86":
        return is_32bit() and m in ("i386", "i686", "x86", "x86_64", "amd64")
    return True


def rules_ok(rules, features=None):
    if not rules:
        return True
    features = features or {}
    ok = False
    for r in rules:
        match = True
        if "os" in r:
            o = r["os"]
            if "name" in o and o["name"] != "linux":
                match = False
            if "arch" in o and not _arch_ok(o["arch"]):
                match = False
        if "features" in r:
            for k, v in r["features"].items():
                if bool(features.get(k)) != v:
                    match = False
        if match:
            ok = (r["action"] == "allow")
    return ok


def maven_path(name):
    ext = "jar"
    if "@" in name:
        name, ext = name.split("@")
    parts = name.split(":")
    g, a, v = parts[0].replace(".", "/"), parts[1], parts[2]
    cl = "-" + parts[3] if len(parts) > 3 else ""
    return "%s/%s/%s/%s-%s%s.%s" % (g, a, v, a, v, cl, ext)


def collect_libs(vj):
    """Returns (download_items, classpath_paths, natives_jars[(path, exclude)])"""
    items, cp, natives, seen = [], [], [], set()
    libdir = os.path.join(GAME, "libraries")
    for lib in vj.get("libraries", []):
        if not rules_ok(lib.get("rules")):
            continue
        parts = lib["name"].split("@")[0].split(":")
        key = ":".join(parts[:2] + parts[3:4])
        if key in seen:          # child (loader) libraries win over vanilla ones
            continue
        seen.add(key)
        dl = lib.get("downloads", {})
        base = lib.get("url", "https://libraries.minecraft.net/")
        nat = lib.get("natives", {}).get("linux")
        if nat:
            nat = nat.replace("${arch}", "64" if sys.maxsize > 2 ** 32 else "32")
            cl = dl.get("classifiers", {}).get(nat)
            if cl:
                p = os.path.join(libdir, cl["path"])
            else:
                rel = maven_path(lib["name"] + ":" + nat)
                p = os.path.join(libdir, rel)
                cl = {"url": base + rel}
            items.append((cl["url"], p, cl.get("sha1")))
            natives.append((p, lib.get("extract", {}).get("exclude", [])))
        art = dl.get("artifact")
        if art is None and not dl and not nat:
            rel = maven_path(lib["name"])
            art = {"path": rel, "url": base + rel}
        if art:
            p = os.path.join(libdir, art["path"])
            if art.get("url"):
                items.append((art["url"], p, art.get("sha1")))
            cp.append(p)
    return items, cp, natives


def extract_natives(natives, outdir):
    os.makedirs(outdir, exist_ok=True)
    for path, excl in natives:
        try:
            with zipfile.ZipFile(path) as z:
                for n in z.namelist():
                    if n.endswith("/") or n.startswith("META-INF") or any(n.startswith(e) for e in excl):
                        continue
                    with open(os.path.join(outdir, os.path.basename(n)), "wb") as f:
                        f.write(z.read(n))
        except zipfile.BadZipFile:
            os.remove(path)
            raise RuntimeError("Corrupt native library, run again: " + path)


def prepare_assets(vj, prog):
    ai = vj["assetIndex"]
    ipath = os.path.join(GAME, "assets", "indexes", ai["id"] + ".json")
    download(ai["url"], ipath, ai.get("sha1")) if not os.path.exists(ipath) else None
    with open(ipath, encoding="utf8") as f:
        idx = json.load(f)
    objs = idx["objects"]
    base = os.path.join(GAME, "assets", "objects")
    items = [("https://resources.download.minecraft.net/%s/%s" % (o["hash"][:2], o["hash"]),
              os.path.join(base, o["hash"][:2], o["hash"]), o["hash"]) for o in objs.values()]
    fetch_all(items, prog)
    assets_dir = os.path.join(GAME, "assets")
    if idx.get("map_to_resources"):
        assets_dir = os.path.join(GAME, "resources")
        target = assets_dir
    elif idx.get("virtual"):
        assets_dir = os.path.join(GAME, "assets", "virtual", ai["id"])
        target = assets_dir
    else:
        return os.path.join(GAME, "assets")
    for name, o in objs.items():
        dst = os.path.join(target, *name.split("/"))
        if not os.path.exists(dst):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(os.path.join(base, o["hash"][:2], o["hash"]), dst)
    return assets_dir


# ───────────────────────── java ─────────────────────────
def java_major(path):
    try:
        out = subprocess.run([path, "-version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             timeout=15).stderr.decode("utf8", "replace")
        m = re.search(r'version "(\d+)(?:\.(\d+))?', out)
        if not m:
            return None
        a = int(m.group(1))
        return int(m.group(2)) if a == 1 else a
    except Exception:
        return None


def system_javas():
    paths = set(glob.glob("/usr/lib/jvm/*/bin/java")) | set(glob.glob("/usr/lib/sdk/openjdk*/jvm/*/bin/java"))
    w = shutil.which("java")
    if w:
        paths.add(w)
    res = {}
    for p in sorted(paths):
        m = java_major(p)
        if m:
            res.setdefault(m, p)
    return res


def mojang_java(component, prog):
    mach = platform.machine().lower()
    if is_32bit():
        plat = "linux-i386" if mach in ("i386", "i686", "x86_64", "amd64") else None
    else:
        plat = "linux" if mach in ("x86_64", "amd64") else None
    if not plat:
        return None
    lst = jget(RUNTIME_ALL).get(plat, {}).get(component) or []
    if not lst:
        return None
    root = os.path.join(HOME, "runtime", component)
    exe, done = os.path.join(root, "bin", "java"), os.path.join(root, ".ok")
    if os.path.exists(done) and os.path.exists(exe):
        return exe
    files = jget(lst[0]["manifest"]["url"])["files"]
    items = []
    for rel, f in files.items():
        p = os.path.join(root, rel)
        if f["type"] == "directory":
            os.makedirs(p, exist_ok=True)
        elif f["type"] == "file":
            r = f["downloads"]["raw"]
            items.append((r["url"], p, r["sha1"]))
    fetch_all(items, prog)
    for rel, f in files.items():
        p = os.path.join(root, rel)
        if f["type"] == "file" and f.get("executable"):
            os.chmod(p, 0o755)
        elif f["type"] == "link" and not os.path.lexists(p):
            os.makedirs(os.path.dirname(p), exist_ok=True)
            os.symlink(f["target"], p)
    open(done, "w").close()
    return exe


def find_java(vj, prog):
    if cfg.get("java") and os.path.exists(cfg["java"]):
        return cfg["java"]
    jv = vj.get("javaVersion", {})
    need, comp = jv.get("majorVersion", 8), jv.get("component", "jre-legacy")
    sysj = system_javas()
    if need in sysj:
        return sysj[need]
    try:
        j = mojang_java(comp, prog)
        if j:
            return j
    except Exception:
        pass
    ok = [m for m in sorted(sysj) if m >= need]
    if ok:
        return sysj[ok[0]]
    raise RuntimeError("Java %d is required. Install it:  sudo apt install openjdk-%d-jre" % (need, need))


def injector_jar():
    p = os.path.join(HOME, "authlib-injector.jar")
    if os.path.exists(p) and os.path.getsize(p) > 0:
        return p
    last = None
    for u in INJECTOR_META:
        try:
            meta = jget(u)
            download(meta["download_url"], p)
            return p
        except Exception as e:
            last = e
    raise RuntimeError("Could not download authlib-injector: %s" % last)


# ───────────────────────── launch ─────────────────────────
def subst(s, d):
    return re.sub(r"\$\{(\w+)\}", lambda m: str(d.get(m.group(1), m.group(0))), s)


def expand_args(lst, d):
    out = []
    for a in lst:
        if isinstance(a, str):
            out.append(subst(a, d))
        elif rules_ok(a.get("rules")):
            v = a["value"]
            out.extend(subst(x, d) for x in ([v] if isinstance(v, str) else v))
    return out


def has_authlib(vj):
    return any("authlib" in l.get("name", "") for l in vj.get("libraries", []))


def build_command(vj, acc, java, ram, classpath, natives_dir, assets_dir, extra_jvm, game_dir=None):
    vid = vj["id"]
    game_dir = game_dir or GAME
    utype = {"microsoft": "msa", "elyby": "mojang"}.get(acc["type"], "legacy")
    d = {"natives_directory": natives_dir, "launcher_name": "xlop", "launcher_version": APP_VER,
         "classpath": classpath, "auth_player_name": acc["name"], "version_name": vid,
         "game_directory": game_dir, "assets_root": assets_dir, "game_assets": assets_dir,
         "assets_index_name": vj["assetIndex"]["id"], "auth_uuid": acc["uuid"],
         "auth_access_token": acc["token"], "auth_session": "token:%s:%s" % (acc["token"], acc["uuid"]),
         "clientid": "", "auth_xuid": "", "user_type": utype, "version_type": vj.get("type", "release"),
         "user_properties": "{}", "resolution_width": "854", "resolution_height": "480",
         "library_directory": os.path.join(GAME, "libraries"), "classpath_separator": os.pathsep}
    if "arguments" in vj:
        jvm = expand_args(vj["arguments"].get("jvm", []), d)
        game = expand_args(vj["arguments"].get("game", []), d)
    else:
        jvm = ["-Djava.library.path=" + natives_dir, "-cp", classpath]
        game = subst(vj.get("minecraftArguments", ""), d).split()
    log = vj.get("logging", {}).get("client")
    if log:
        lp = os.path.join(GAME, "assets", "log_configs", log["file"]["id"])
        jvm.append(subst(log["argument"], {"path": lp}))
    mem = ["-Xmx%dM" % ram, "-Xms%dM" % min(512, ram)]
    return [java] + mem + extra_jvm + jvm + [vj["mainClass"]] + game


# ───────────────────────── mod loaders ─────────────────────────
LOADERS = ["vanilla", "fabric", "quilt", "forge", "neoforge"]


def instance_dir(mc, loader, pack=None):
    """Vanilla keeps the classic folder; every modded combo (or imported modpack) gets its own."""
    if pack:
        return os.path.join(GAME, "instances", pack)
    return GAME if loader == "vanilla" else os.path.join(GAME, "instances", "%s-%s" % (mc, loader))


def _vkey(s):
    return [int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", s)]


def list_loader_versions(loader, mc):
    """Available loader versions for a Minecraft version, newest first."""
    if loader in ("fabric", "quilt"):
        base = {"fabric": "https://meta.fabricmc.net/v2", "quilt": "https://meta.quiltmc.org/v3"}[loader]
        return [x["loader"]["version"] for x in jget("%s/versions/loader/%s" % (base, urllib.parse.quote(mc)))]
    if loader == "forge":
        import xml.etree.ElementTree as ET
        root = ET.fromstring(fetch_bytes("https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml"))
        pre = mc + "-"
        vs = [v.text[len(pre):] for v in root.iter("version") if v.text.startswith(pre)]
        return sorted(vs, key=_vkey, reverse=True)
    pre = _neo_prefix(mc)
    vs = jget("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge")["versions"]
    return sorted([v for v in vs if v.startswith(pre)], key=_vkey, reverse=True)


def _neo_prefix(mc):
    if mc.startswith("1."):
        p = mc.split(".")[1:]
        return "%s.%s." % (p[0], p[1] if len(p) > 1 else "0")
    return mc + "."


def _installer_url(loader, mc, ver=None):
    if loader == "forge":
        if not ver:
            promos = jget("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json")["promos"]
            ver = promos.get(mc + "-recommended") or promos.get(mc + "-latest")
            if not ver:
                raise RuntimeError("Forge has no build for Minecraft " + mc)
        full = "%s-%s" % (mc, ver)
        return "https://maven.minecraftforge.net/net/minecraftforge/forge/%s/forge-%s-installer.jar" % (full, full)
    if not ver:
        vs = list_loader_versions("neoforge", mc)
        if not vs:
            raise RuntimeError("NeoForge has no build for Minecraft " + mc)
        ver = next((v for v in vs if not re.search("alpha|beta", v)), vs[0])
    return "https://maven.neoforged.net/releases/net/neoforged/neoforge/%s/neoforge-%s-installer.jar" % (ver, ver)


def _run_installer(loader, mc, java, log, ver=None):
    url = _installer_url(loader, mc, ver)
    inst = os.path.join(HOME, "installers", os.path.basename(url))
    if not os.path.exists(inst):
        download(url, inst)
    lp = os.path.join(GAME, "launcher_profiles.json")
    if not os.path.exists(lp):
        with open(lp, "w") as f:
            json.dump({"profiles": {}}, f)
    vdir = os.path.join(GAME, "versions")
    os.makedirs(vdir, exist_ok=True)
    before = set(os.listdir(vdir))
    p = subprocess.Popen([java, "-jar", inst, "--installClient", GAME], stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    for line in iter(p.stdout.readline, b""):
        log("[installer] " + line.decode("utf8", "replace").rstrip())
    if p.wait() != 0:
        raise RuntimeError("%s installer failed — see the log below" % loader.title())
    mine = [d for d in os.listdir(vdir) if loader in d.lower() and (not ver or ver in d)]
    new = [d for d in mine if d not in before] or sorted(
        mine, key=lambda d: os.path.getmtime(os.path.join(vdir, d)))[-1:]
    if not new:
        raise RuntimeError("Could not find the installed %s version" % loader.title())
    return new[0]


def install_loader(loader, mc, java, status, log, ver=None):
    """Makes sure the loader profile exists; returns its version id. ver=None means latest."""
    cache = cfg.setdefault("loaders", {})
    key = "%s:%s:%s" % (loader, mc, ver or "auto")
    vid = cache.get(key)
    if vid and os.path.exists(os.path.join(GAME, "versions", vid, vid + ".json")):
        return vid
    status("Installing %s for %s…" % (loader.title(), mc))
    if loader in ("fabric", "quilt"):
        base = {"fabric": "https://meta.fabricmc.net/v2", "quilt": "https://meta.quiltmc.org/v3"}[loader]
        q = urllib.parse.quote(mc)
        pick = ver
        if not pick:
            lst = jget("%s/versions/loader/%s" % (base, q))
            if not lst:
                raise RuntimeError("%s does not support Minecraft %s" % (loader.title(), mc))
            pick = next((x for x in lst if x["loader"].get("stable", True)), lst[0])["loader"]["version"]
        prof = jget("%s/versions/loader/%s/%s/profile/json" % (base, q, pick))
        vid = prof["id"]
        p = os.path.join(GAME, "versions", vid, vid + ".json")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf8") as f:
            json.dump(prof, f)
    else:
        vid = _run_installer(loader, mc, java, log, ver)
    cache[key] = vid
    save_cfg()
    return vid


def import_mrpack(path, status, prog):
    """Imports a Modrinth modpack (.mrpack) into its own profile. Returns the profile slug."""
    with zipfile.ZipFile(path) as z:
        try:
            idx = json.loads(z.read("modrinth.index.json").decode("utf8"))
        except KeyError:
            raise RuntimeError("This is not a valid .mrpack file")
        deps = idx.get("dependencies", {})
        mc = deps.get("minecraft")
        if not mc:
            raise RuntimeError("The modpack does not say which Minecraft version it needs")
        loader, ver = "vanilla", None
        for k, l in (("fabric-loader", "fabric"), ("quilt-loader", "quilt"),
                     ("neoforge", "neoforge"), ("forge", "forge")):
            if k in deps:
                loader, ver = l, deps[k]
                break
        name = idx.get("name") or os.path.splitext(os.path.basename(path))[0]
        slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "pack"
        root = os.path.realpath(os.path.join(GAME, "instances", slug))
        os.makedirs(root, exist_ok=True)
        items = []
        for f in idx.get("files", []):
            if f.get("env", {}).get("client") == "unsupported" or not f.get("downloads"):
                continue
            dst = os.path.realpath(os.path.join(root, f["path"]))
            if not dst.startswith(root + os.sep):
                raise RuntimeError("Unsafe file path in modpack: " + f["path"])
            items.append((f["downloads"][0], dst, f.get("hashes", {}).get("sha1")))
        status("Downloading modpack files…")
        fetch_all(items, lambda a, n: (prog(a / max(n, 1)), status("Modpack files %d/%d" % (a, n))))
        for pre in ("overrides/", "client-overrides/"):
            for n in z.namelist():
                if n.startswith(pre) and not n.endswith("/"):
                    dst = os.path.realpath(os.path.join(root, n[len(pre):]))
                    if dst.startswith(root + os.sep):
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        with open(dst, "wb") as out:
                            out.write(z.read(n))
    cfg.setdefault("packs", {})[slug] = {"name": name, "mc": mc, "loader": loader, "ver": ver}
    save_cfg()
    return slug


def prepare_and_launch(vid, acc, skin_server, status, prog, log, loader="vanilla",
                       loader_ver=None, pack=None):
    """Runs on a worker thread. status(text), prog(fraction), log(line)."""
    os.makedirs(GAME, exist_ok=True)
    status("Reading version list…")
    manifest = get_manifest()
    real = vid
    if loader != "vanilla":
        status("Checking Java…")
        j0 = find_java(get_version_json(vid, manifest), lambda a, n: status("Java %d/%d" % (a, n)))
        real = install_loader(loader, vid, j0, status, log, loader_ver)
    vj = get_version_json(real, manifest)
    check_platform(vj)
    base = vj.get("_base", vj["id"])
    gdir = instance_dir(vid, loader, pack)
    os.makedirs(gdir, exist_ok=True)
    if loader != "vanilla":
        os.makedirs(os.path.join(gdir, "mods"), exist_ok=True)

    status("Checking account…")
    refresh_account(acc)

    status("Downloading game…")
    jar = os.path.join(GAME, "versions", base, base + ".jar")
    c = vj["downloads"]["client"]
    fetch_all([(c["url"], jar, c.get("sha1"))])
    items, cp, nat = collect_libs(vj)
    fetch_all(items, lambda a, n: (prog(a / max(n, 1) * 0.3), status("Libraries %d/%d" % (a, n))))
    lg = vj.get("logging", {}).get("client")
    if lg:
        fetch_all([(lg["file"]["url"], os.path.join(GAME, "assets", "log_configs", lg["file"]["id"]),
                    lg["file"].get("sha1"))])
    status("Preparing assets…")
    assets_dir = prepare_assets(vj, lambda a, n: (prog(0.3 + a / max(n, 1) * 0.6),
                                                  status("Assets %d/%d" % (a, n))))
    natives_dir = os.path.join(GAME, "versions", real, "natives")
    extract_natives(nat, natives_dir)

    status("Preparing Java…")
    java = find_java(vj, lambda a, n: (prog(0.9 + a / max(n, 1) * 0.1), status("Java %d/%d" % (a, n))))

    extra = []
    if acc["type"] == "elyby" or (acc["type"] == "offline" and acc.get("skin")):
        if has_authlib(vj):
            status("Preparing skin support…")
            inj = injector_jar()
            if acc["type"] == "elyby":
                extra.append("-javaagent:%s=%s" % (inj, ELY_INJECTOR_API))
            else:
                skin_server.set(acc)
                extra.append("-javaagent:%s=%s" % (inj, skin_server.url))
        else:
            log("[xlop] This old version cannot load custom skins (no authlib). Skipping.")
    ram = int(cfg.get("ram", 2048))
    if is_32bit():
        ram = min(ram, 1536)      # 32-bit JVMs cannot address more
    cmd = build_command(vj, acc, java, ram,
                        os.pathsep.join(cp + [jar]), natives_dir, assets_dir, extra, gdir)
    prog(1.0)
    status("Running Minecraft %s%s" % (vid, "" if loader == "vanilla" else " + " + loader.title()))
    log("[xlop] " + " ".join(cmd[:3]) + " …")
    proc = subprocess.Popen(cmd, cwd=gdir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in iter(proc.stdout.readline, b""):
        log(line.decode("utf8", "replace").rstrip())
    return proc.wait()
